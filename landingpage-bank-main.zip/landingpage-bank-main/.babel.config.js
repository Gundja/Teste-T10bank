module.exports = {
  presets: ["next/babel"],
  plugins: [],
};
