module.exports = {
  singleQuote: false,
};
